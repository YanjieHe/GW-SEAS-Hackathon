package com.company.VideoCommunity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VideoCommunityApplication {

	public static void main(String[] args) {
		SpringApplication.run(VideoCommunityApplication.class, args);
	}

}
